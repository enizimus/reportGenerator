v1 = 1:10;
fh(1)=figure;
plot(v1,v1.^2)
v2 = 1:20;
fh(2)=figure;
plot(v2,v2.^2,'r')
v3 = 1:20;
fh(3)=figure;
plot(v3,v3.^2,'ro')
