oldpath = path;

% YOUR PATH GOES HERE | 
%                     |
%                     |
%                     v
path(oldpath,'C:\Users\enizm\AppData\Local\Programs\MiKTeX 2.9\miktex\bin\x64');